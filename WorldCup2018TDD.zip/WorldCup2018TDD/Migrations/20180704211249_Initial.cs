﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WorldCup2018TDD.Migrations
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Nations",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Championships = table.Column<int>(nullable: false),
                    Confederation = table.Column<string>(nullable: true),
                    Draws = table.Column<int>(nullable: false),
                    GroupLetter = table.Column<string>(nullable: true),
                    GroupStageGoalsAgainst = table.Column<int>(nullable: false),
                    GroupStageGoalsDifference = table.Column<int>(nullable: false),
                    GroupStageGoalsFor = table.Column<int>(nullable: false),
                    Loses = table.Column<int>(nullable: false),
                    MatchesPlayed = table.Column<int>(nullable: false),
                    Name = table.Column<string>(nullable: true),
                    Points = table.Column<int>(nullable: false),
                    Ranking = table.Column<int>(nullable: false),
                    TotalGoalsAgainst = table.Column<int>(nullable: false),
                    TotalGoalsDifference = table.Column<int>(nullable: false),
                    TotalGoalsFor = table.Column<int>(nullable: false),
                    Wins = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Nations", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Fixtures",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    NationOneId = table.Column<int>(nullable: true),
                    NationOneScore = table.Column<int>(nullable: false),
                    NationTwoId = table.Column<int>(nullable: true),
                    NationTwoScore = table.Column<int>(nullable: false),
                    Round = table.Column<string>(nullable: true),
                    WinnerId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Fixtures", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Fixtures_Nations_NationOneId",
                        column: x => x.NationOneId,
                        principalTable: "Nations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Fixtures_Nations_NationTwoId",
                        column: x => x.NationTwoId,
                        principalTable: "Nations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Fixtures_Nations_WinnerId",
                        column: x => x.WinnerId,
                        principalTable: "Nations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Groups",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Letter = table.Column<string>(nullable: true),
                    NationFourId = table.Column<int>(nullable: true),
                    NationOneId = table.Column<int>(nullable: true),
                    NationThreeId = table.Column<int>(nullable: true),
                    NationTwoId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Groups", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Groups_Nations_NationFourId",
                        column: x => x.NationFourId,
                        principalTable: "Nations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Groups_Nations_NationOneId",
                        column: x => x.NationOneId,
                        principalTable: "Nations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Groups_Nations_NationThreeId",
                        column: x => x.NationThreeId,
                        principalTable: "Nations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Groups_Nations_NationTwoId",
                        column: x => x.NationTwoId,
                        principalTable: "Nations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Fixtures_NationOneId",
                table: "Fixtures",
                column: "NationOneId");

            migrationBuilder.CreateIndex(
                name: "IX_Fixtures_NationTwoId",
                table: "Fixtures",
                column: "NationTwoId");

            migrationBuilder.CreateIndex(
                name: "IX_Fixtures_WinnerId",
                table: "Fixtures",
                column: "WinnerId");

            migrationBuilder.CreateIndex(
                name: "IX_Groups_NationFourId",
                table: "Groups",
                column: "NationFourId");

            migrationBuilder.CreateIndex(
                name: "IX_Groups_NationOneId",
                table: "Groups",
                column: "NationOneId");

            migrationBuilder.CreateIndex(
                name: "IX_Groups_NationThreeId",
                table: "Groups",
                column: "NationThreeId");

            migrationBuilder.CreateIndex(
                name: "IX_Groups_NationTwoId",
                table: "Groups",
                column: "NationTwoId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Fixtures");

            migrationBuilder.DropTable(
                name: "Groups");

            migrationBuilder.DropTable(
                name: "Nations");
        }
    }
}
