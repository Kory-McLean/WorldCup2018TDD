﻿using System.Collections.Generic;
using WorldCup2018TDD.Data.Entities;

namespace WorldCup2018TDD.ViewModels
{
    public class SimulationBreakdownViewModel
    {
        public List<Nation> TopFiveHighestScorers { get; set; }
        public List<Nation> FiveWorstDefences { get; set; }
        public List<Fixture> TopFiveHighestScoringMatches { get; set; }
        public List<Fixture> TopFiveHighestWinningMargins { get; set; }
        public List<Nation> TopFourNations { get; set; }
        public int CurrentRound { get; set; }
    }
}
