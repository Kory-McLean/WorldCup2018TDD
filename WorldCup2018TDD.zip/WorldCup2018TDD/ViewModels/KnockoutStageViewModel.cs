﻿using System.Collections.Generic;
using WorldCup2018TDD.Data.Entities;

namespace WorldCup2018TDD.ViewModels
{
    public class KnockoutStageViewModel
    {
        public List<Fixture> RoundOf16 { get; set; }
        public List<Fixture> QuarterFinals { get; set; }
        public List<Fixture> SemiFinals { get; set; }
        public List<Fixture> ThirdPlace { get; set; }
        public List<Fixture> Final { get; set; }
        public int CurrentRound { get; set; }
        public string CurrentKnockoutStage { get; set; }
    }
}
