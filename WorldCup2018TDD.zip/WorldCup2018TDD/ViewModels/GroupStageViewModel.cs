﻿using System.Collections.Generic;
using WorldCup2018TDD.Data;
using WorldCup2018TDD.Data.Entities;

namespace WorldCup2018TDD.ViewModels
{
    public class GroupStageViewModel
    {
        public List<Standings> Standings { get; set; }
        public List<List<Fixture>> RecentFixtures { get; set; }
        public int RecentRound { get; set; }
        public string[] GroupLetters { get; set; }
    }
}
