﻿using System.Collections.Generic;
using WorldCup2018TDD.Data.Entities;

namespace WorldCup2018TDD.Services.Tournaments
{
    public interface ITournamentService
    {
        List<Fixture> GetFixturesFromGroup(Group group);

        void AddFixturesFromGroup(Group group);

        List<Nation> GetStandingsFromGroup(Group group);

        void ResetTournament();

        List<Nation> GetGroupAdvancers(Group group);

        void IncreaseRound();

        int GetTournamentRound();
        string GetKnockoutRound();
        string GetNextRound(string round);
        Dictionary<string, List<Nation>> GenerateSeedingDictionary(List<string> groupLetters);
        Fixture GetThirdPlaceMatch(List<Fixture> list);
        int GetRandomIndex(int upperBound);
        List<Group> MakeRandomGroups(List<Nation> nations);
        void AdvanceKnockoutRounds(List<Fixture> fixturesPlayed);
        void SeedRoundOf16();
        void SeedRandomGroups();
        List<Nation> GetTopFourNations();
    }
}
