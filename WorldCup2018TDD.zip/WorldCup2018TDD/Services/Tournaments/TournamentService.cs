﻿using System;
using System.Collections.Generic;
using System.Linq;
using WorldCup2018TDD.Data;
using WorldCup2018TDD.Data.Entities;
using WorldCup2018TDD.Services.Fixtures;

namespace WorldCup2018TDD.Services.Tournaments
{
    public class TournamentService : ITournamentService
    {
        private readonly INationService nationService;
        private readonly IGroupService groupService;
        private readonly IFixtureService fixtureService;
        private Dictionary<string, string> roundAdvancementDictionary = new Dictionary<string, string>(){
            { "Round of 16", "Quarter Final" },
            { "Quarter Final", "Semi Final" },
            { "Semi Final", "Final" }
        };
        private Dictionary<int, string> tournamentRoundNumberToStringDictionary = new Dictionary<int, string>(){
            { 4, "Round of 16" },
            { 5, "Quarter Final" },
            { 6, "Semi Final" },
            {7, "Final" }
        };
        public static int tournamentRound = 1;

        public TournamentService(IGroupService groupService)
        {
            this.groupService = groupService;
        }

        public TournamentService(WorldCupTDDDbContext dbContext)
        {
            groupService = new GroupService(dbContext);
            fixtureService = new FixtureService(dbContext);
            nationService = new NationService(dbContext);
        }

        public List<Fixture> GetFixturesFromGroup(Group group)
        {
            List<Fixture> fixturesToPlay = new List<Fixture>() {
                new Fixture() { NationOne = group.NationOne, NationTwo = group.NationTwo, Round = $"{group.Letter}-1"},
                new Fixture() { NationOne = group.NationThree, NationTwo = group.NationFour, Round = $"{group.Letter}-1" },
                new Fixture() { NationOne = group.NationTwo, NationTwo = group.NationFour, Round = $"{group.Letter}-2" },
                new Fixture() { NationOne = group.NationOne, NationTwo = group.NationThree, Round = $"{group.Letter}-2" },
                new Fixture() { NationOne = group.NationOne, NationTwo = group.NationFour, Round = $"{group.Letter}-3" },
                new Fixture() { NationOne = group.NationTwo, NationTwo = group.NationThree, Round = $"{group.Letter}-3" }
            };
            return fixturesToPlay;
        }

        public List<Nation> GetTopFourNations()
        {
            Nation winner = fixtureService.GetFixturesByRound("Final")[0].Winner;
            Nation second = fixtureService.GetFixturesByRound("Final")[0].Winner == fixtureService.GetFixturesByRound("Final")[0].NationOne ?
                fixtureService.GetFixturesByRound("Final")[0].NationTwo : fixtureService.GetFixturesByRound("Final")[0].NationOne;
            Nation third = fixtureService.GetFixturesByRound("Third Place")[0].Winner;
            Nation fourth  = fixtureService.GetFixturesByRound("Third Place")[0].Winner == fixtureService.GetFixturesByRound("Third Place")[0].NationOne ?
                fixtureService.GetFixturesByRound("Third Place")[0].NationTwo : fixtureService.GetFixturesByRound("Third Place")[0].NationOne; ;
            return new List<Nation>() {winner,  second, third, fourth };
        }

        public void AddFixturesFromGroup(Group group)
        {
            if (tournamentRound == 1)
            {
                fixtureService.AddFixturesToDb(GetFixturesFromGroup(group));
            }
        }

        public List<Nation> GetStandingsFromGroup(Group group)
        {
            List<Nation> standingsToReturn = new List<Nation>() { group.NationOne, group.NationTwo, group.NationThree, group.NationFour };
            return standingsToReturn.OrderByDescending(n => n.Points).ThenByDescending(n => n.GroupStageGoalsDifference).ToList();
        }

        public int GetTournamentRound()
        {
            return tournamentRound;
        }

        public List<Nation> GetGroupAdvancers(Group group)
        {
            return GetStandingsFromGroup(group).Take(2).ToList();
        }

        public void IncreaseRound()
        {
            tournamentRound++;
        }

        public void ResetTournament()
        {
            nationService.ResetStats();
            fixtureService.ResetFixtures();
            groupService.ResetGroups();
            tournamentRound = 1;
        }

        public Dictionary<string, List<Nation>> GenerateSeedingDictionary(List<string> letters)
        {
            Dictionary<string, List<Nation>> result = new Dictionary<string, List<Nation>>();
            foreach (string letter in letters)
            {
                result[letter] = GetGroupAdvancers(groupService.GetGroupByLetter(letter));
            }
            return result;
        }

        public void SeedRandomGroups()
        {
            groupService.AddGroupsToDb(MakeRandomGroups(nationService.GetAllNations()));
        }

        public void SeedRoundOf16()
        {
            List<string> groupLetters = new List<string>() { "A", "B", "C", "D", "E", "F", "G", "H" };
            Dictionary<string, List<Nation>> advancers = GenerateSeedingDictionary(groupLetters);
            int i = 0;
            while (i + 1 < groupLetters.Count)
            {
                Fixture newFixtureOne = new Fixture() {
                    Round = "Round of 16",
                    NationOne = advancers[groupLetters[i]][0],
                    NationTwo = advancers[groupLetters[i + 1]][1]
                };

                Fixture newFixtureTwo = new Fixture()
                {
                    Round = "Round of 16",
                    NationOne = advancers[groupLetters[i + 1]][0],
                    NationTwo = advancers[groupLetters[i]][1]
                };
                fixtureService.AddFixturesToDb(new List<Fixture>() { newFixtureOne, newFixtureTwo });

                i += 2;
            }
        }

        public void AdvanceKnockoutRounds(List<Fixture> fixturesPlayed)
        {
            List<Fixture> newFixtures = new List<Fixture>();
            for (int i = 0; i + 1 < fixturesPlayed.Count; i += 2)
            {
                Fixture fixtureToAdd = new Fixture() {
                NationOne = fixturesPlayed[i].Winner,
                NationTwo = fixturesPlayed[i+1].Winner,
                Round = GetNextRound(fixturesPlayed[i].Round)};
                newFixtures.Add(fixtureToAdd);
            }
            fixtureService.AddFixturesToDb(newFixtures);
        }

        public List<Group> MakeRandomGroups(List<Nation> _nations)
        {
            List<Nation> nations = _nations;
            List<string> groupLetters = new List<string>() { "A", "B", "C", "D", "E", "F", "G", "H" };
            List<Group> result = new List<Group>();
            for (int i = 0; i < 8; i++)
            {
                Nation nationOne = nations[GetRandomIndex(nations.Count)];
                nations.Remove(nationOne);
                Nation nationTwo = nations[GetRandomIndex(nations.Count)];
                nations.Remove(nationTwo);
                Nation nationThree = nations[GetRandomIndex(nations.Count)];
                nations.Remove(nationThree);
                Nation nationFour = nations[GetRandomIndex(nations.Count)];
                nations.Remove(nationFour);
                result.Add(new Group() {
                    Letter = groupLetters[i],
                    NationOne = nationOne,
                    NationTwo = nationTwo,
                    NationThree = nationThree,
                    NationFour = nationFour
                });
            }
            return result;
        }

        public int GetRandomIndex(int upperBound)
        {
            Random randomIntGenerator = new Random();
            return randomIntGenerator.Next(upperBound);
        }

        public Fixture GetThirdPlaceMatch(List<Fixture> list)
        {
            Nation nationOne = list[0].Winner == list[0].NationOne ? list[0].NationTwo : list[0].NationOne;
            Nation nationTwo = list[1].Winner == list[1].NationOne ? list[1].NationTwo : list[1].NationOne;
            return new Fixture() { NationOne = nationOne, NationTwo = nationTwo, Round = "Third Place"};
        }

        public string GetNextRound(string round)
        {
            GenerateThirdPlaceMatchIfAppropriate(round);
            return roundAdvancementDictionary[round];
        }
        private void GenerateThirdPlaceMatchIfAppropriate(string currentRound)
        {
            if (currentRound == "Semi Final") {
                fixtureService.AddFixturesToDb(new List<Fixture>() { GetThirdPlaceMatch(fixtureService.GetFixturesByRound("Semi Final")) });
            }
        }

        public string GetKnockoutRound()
        {
            return GetTournamentRound() > 7 ? "" : tournamentRoundNumberToStringDictionary[GetTournamentRound()];
        }
    }
}
