﻿using System.Collections.Generic;
using WorldCup2018TDD.Data.Entities;

namespace WorldCup2018TDD.Services.Fixtures
{
    public interface IFixtureService
    {
        Fixture GetFixtureById(int id);
        void AddFixturesToDb(List<Fixture> fixturesToAdd);
        void SaveChanges();
        void ResetFixtures();
        List<Fixture> GetFixturesByRound(string round);
        List<List<Fixture>> GetFixturesByRoundNumber(int number);
        List<Fixture> GetHighestScoringMatches(int count);
        List<Fixture> GetHighestWinningMargins(int count);
        List<Fixture> GetAllGroupFixtures();
        bool IsGroupFixture(Fixture fixture);
    }
}
