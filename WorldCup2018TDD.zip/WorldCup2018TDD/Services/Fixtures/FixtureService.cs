﻿using System;
using System.Collections.Generic;
using WorldCup2018TDD.Data;
using WorldCup2018TDD.Data.Entities;
using WorldCup2018TDD.Data.Repositories.Fixtures;

namespace WorldCup2018TDD.Services.Fixtures
{
    public class FixtureService : IFixtureService
    {
        private readonly IFixtureRepository fixtureRepository;

        public FixtureService(IFixtureRepository fixtureRepository)
        {
            this.fixtureRepository = fixtureRepository;
        }

        public FixtureService(WorldCupTDDDbContext dbContext)
        {
            fixtureRepository = new FixtureRepository(dbContext);
        }

        public Fixture GetFixtureById(int id)
        {
            return fixtureRepository.GetFixtureById(id);
        }

        public void AddFixturesToDb(List<Fixture> fixturesToAdd)
        {
            fixtureRepository.AddFixturesToDb(fixturesToAdd);
        }

        public List<Fixture> GetFixturesByRound(string round)
        {
            return fixtureRepository.GetFixturesByRound(round);
        }

        public void SaveChanges()
        {
            fixtureRepository.SaveChanges();
        }

        public void ResetFixtures()
        {
            fixtureRepository.ResetFixtures();
        }

        public List<List<Fixture>> GetFixturesByRoundNumber(int roundNumber)
        {
            return fixtureRepository.GetFixturesByRoundNumber(roundNumber);
        }

        public List<Fixture> GetHighestScoringMatches(int count)
        {
            return fixtureRepository.GetHighestScoringMatches(count);
        }

        public List<Fixture> GetHighestWinningMargins(int count)
        {
            return fixtureRepository.GetHighestWinningMargins(count);
        }

        public List<Fixture> GetAllGroupFixtures()
        {
            return fixtureRepository.GetAllGroupFixtures();
        }
        public bool IsGroupFixture(Fixture fixture)
        {
            return fixtureRepository.IsGroupFixture(fixture);
        }
    }
}
