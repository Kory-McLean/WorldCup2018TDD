﻿using System.Collections.Generic;
using WorldCup2018TDD.Data.Entities;

namespace WorldCup2018TDD.Services
{
    public interface IGroupService
    {
        List<Group> GetAllGroups();
        Group GetGroupByLetter(string groupLetter);
        Group AssignNationsToGroup(List<Nation> nations, string groupLetter);
        void PopulateGroups();
        void ResetGroups();
        void AddGroupsToDb(List<Group> groups);
    }
}
