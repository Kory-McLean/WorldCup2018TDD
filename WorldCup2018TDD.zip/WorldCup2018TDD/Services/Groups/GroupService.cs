﻿using System.Collections.Generic;
using WorldCup2018TDD.Data;
using WorldCup2018TDD.Data.Entities;
using WorldCup2018TDD.Data.Repositories;

namespace WorldCup2018TDD.Services
{
    public class GroupService : IGroupService
    {
        private readonly IGroupRepository groupRepository;
        private NationService nationService;

        public GroupService(IGroupRepository groupRepository)
        {
            this.groupRepository = groupRepository;
        }
        public GroupService(WorldCupTDDDbContext dbContext)
        {
            groupRepository = new GroupRepository(dbContext);
            nationService = new NationService(dbContext);
        }

        public List<Group> GetAllGroups()
        {
            return groupRepository.GetAllGroups();
        }

        public Group GetGroupByLetter(string groupLetter)
        {
            return groupRepository.GetGroupByLetter(groupLetter);
        }

        public Group AssignNationsToGroup(List<Nation> nations, string groupLetter)
        {
            Group result =  new Group()
            {
                NationOne = nations[0],
                NationTwo = nations[1],
                NationThree = nations[2],
                NationFour = nations[3],
                Letter = groupLetter,
            };
            return result;
        }

        public void PopulateGroups()
        {
            if (!groupRepository.AreThereGroups()) {
                List<string> groupLetters = new List<string>() { "A", "B", "C", "D", "E", "F", "G", "H" };
                foreach (string letter in groupLetters)
                {
                    Group groupToBeAdded = AssignNationsToGroup(nationService.GetNationsByGroup(letter), letter);
                    groupRepository.AddGroup(groupToBeAdded);
                }
            }
        }

        public void ResetGroups()
        {
            groupRepository.ResetGroups();
        }

        public void AddGroupsToDb(List<Group> groups)
        {
            groupRepository.AddGroups(groups);
        }
    }
}
