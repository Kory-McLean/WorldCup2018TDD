﻿using System.Collections.Generic;
using WorldCup2018TDD.Data.Entities;

namespace WorldCup2018TDD.Services
{
    public interface INationService
    {
        List<Nation> GetAllNations();
        void ResetStats();
        List<Nation> GetNationsByGroup(string groupLetter);
        List<Nation> GetWorstDefences(int count);
        List<Nation> GetHighestScorers(int count);
        Nation GetNationByName(string name);
    }
}
