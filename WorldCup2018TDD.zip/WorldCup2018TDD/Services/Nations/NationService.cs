﻿using System.Collections.Generic;
using WorldCup2018TDD.Data;
using WorldCup2018TDD.Data.Entities;
using WorldCup2018TDD.Data.Repositories;

namespace WorldCup2018TDD.Services
{
    public class NationService : INationService
    {
        INationRepository nationRepository;
        public NationService(INationRepository nationRepository)
        {
            this.nationRepository = nationRepository;
        }

        public NationService(WorldCupTDDDbContext dbContext)
        {
            nationRepository = new NationRepository(dbContext);
        }

        public List<Nation> GetAllNations()
        {
            return nationRepository.GetAllNations();
        }

        public Nation GetNationByName(string name)
        {
            return nationRepository.GetNationByName(name);
        }

        public List<Nation> GetNationsByGroup(string groupLetter)
        {
            return nationRepository.GetNationsByGroup(groupLetter);
        }

        public void ResetStats()
        {
            nationRepository.ResetStats();
        }

        public List<Nation> GetHighestScorers(int count)
        {
            return nationRepository.GetHighestScorers(count);
        }

        public List<Nation> GetWorstDefences(int count)
        {
            return nationRepository.GetWorstDefences(count);
        }
    }
}
