﻿using System.Collections.Generic;
using WorldCup2018TDD.Data.Entities;

namespace WorldCup2018TDD.Services.Simulations
{
    public interface ISimulationService
    {
        void PlayKnockoutFixture(Fixture fixture);
        void PlayNormalFixture(Fixture fixture);
        void PlayPenalties(Fixture fixture);
        void PlayExtratime(Fixture fixture);
        void PlayKnockoutRound(List<Fixture> fixtures);
        void SortNationGoalStats(Fixture fixture);
    }
}
