﻿using System;
using System.Collections.Generic;
using WorldCup2018TDD.Data;
using WorldCup2018TDD.Data.Entities;
using WorldCup2018TDD.Services.Fixtures;
using WorldCup2018TDD.Services.Tournaments;

namespace WorldCup2018TDD.Services.Simulations
{
    public class SimulationService : ISimulationService
    {
        private readonly IFixtureService fixtureService;
        private readonly IGroupService groupService;
        private readonly ITournamentService tournamentService;

        public SimulationService(IFixtureService fixtureService)
        {
            this.fixtureService = fixtureService;
        }

        public SimulationService(WorldCupTDDDbContext dbContext)
        {
            fixtureService = new FixtureService(dbContext);
            tournamentService = new TournamentService(dbContext);
            groupService = new GroupService(dbContext);
        }

        public void PlayNormalFixture(Fixture fixture)
        {
            PlayMatchPeriod(fixture, 90);
            AssignWinnerToFixture(fixture);
            SortNationGoalStats(fixture);
            UpdateNationMatchStats(fixture);
            fixtureService.SaveChanges();
        }

        public void PlayKnockoutFixture(Fixture fixture)
        {
            PlayMatchPeriod(fixture, 90);
            AssignWinnerToFixture(fixture);
            SortNationGoalStats(fixture);
            fixtureService.SaveChanges();
            if (fixture.Winner == null)
            {
                PlayExtratime(fixture);
                if (fixture.Winner == null)
                {
                    PlayPenalties(fixture);
                }
            }
        }

        public void PlayPenalties(Fixture fixture)
        {
            int nation1Score = 0;
            int nation2Score = 0;
            while (nation1Score == nation2Score)
            {
                nation1Score = IsChanceScored(GetNationScoringProbability(fixture.NationOne)) ? nation1Score + 1 : nation1Score;
                nation2Score = IsChanceScored(GetNationScoringProbability(fixture.NationTwo)) ? nation2Score + 1 : nation2Score;
            }
            fixture.NationOneScore += nation1Score;
            fixture.NationTwoScore += nation2Score;
            AssignWinnerToFixture(fixture);
            SortNationGoalStats(fixture);
            fixtureService.SaveChanges();
        }

        public void PlayExtratime(Fixture fixture)
        {
            PlayMatchPeriod(fixture, 30);
            AssignWinnerToFixture(fixture);
            SortNationGoalStats(fixture);
            fixtureService.SaveChanges();
        }

        private void PlayMatchPeriod(Fixture fixture, int minutes)
        {
            int nation1Score = 0;
            int nation2Score = 0;
            for (int min = 0; min < minutes; min++)
            {
                if (CreateChanceAndScoreForNation(fixture.NationOne))
                {
                    nation1Score += 1;
                }
                else if (CreateChanceAndScoreForNation(fixture.NationTwo))
                {
                    nation2Score += 1;
                }
            }
            fixture.NationOneScore += nation1Score;
            fixture.NationTwoScore += nation2Score;
        }

        private bool CreateChanceAndScoreForNation(Nation nation)
        {
            Random randomChanceCreator = new Random();
            int nation1ChanceCreator = randomChanceCreator.Next(0, 121);
            int nation2ChanceCreator = randomChanceCreator.Next(0, 121);
            return ChanceCreatedForFirstNation(nation2ChanceCreator, nation1ChanceCreator) && IsChanceScored(GetNationScoringProbability(nation));
        }

        private bool ChanceCreatedForFirstNation(int firstNationChance, int secondNationChance)
        {
            return firstNationChance > secondNationChance + 60;
        }

        private bool IsChanceScored(double scoringProbability)
        {
            return (scoringProbability / 100) > 0.8;
        }

        private double GetNationScoringProbability(Nation nation)
        {
            Random scoreProb = new Random();
            return (100 - nation.Ranking) * scoreProb.NextDouble();
        }

        public void SortNationGoalStats(Fixture fixture)
        {
            //Goals For
            if (fixtureService.IsGroupFixture(fixture))
            {
                SortGoalsForGroupFixture(fixture);
            }
            else
            {
                SortGoalsForKnockoutFixture(fixture);
            }
        }

        private void SortGoalsForKnockoutFixture(Fixture fixture)
        {
            fixture.NationOne.TotalGoalsFor += fixture.NationOneScore;
            fixture.NationTwo.TotalGoalsFor += fixture.NationTwoScore;


            //Goals against
            fixture.NationOne.TotalGoalsAgainst += fixture.NationTwoScore;
            fixture.NationTwo.TotalGoalsAgainst += fixture.NationOneScore;


            //Goal Difference
            fixture.NationOne.TotalGoalsDifference = fixture.NationOne.TotalGoalsFor - fixture.NationOne.TotalGoalsAgainst;
            fixture.NationTwo.TotalGoalsDifference = fixture.NationTwo.TotalGoalsFor - fixture.NationTwo.TotalGoalsAgainst;

        }

        private static void SortGoalsForGroupFixture(Fixture fixture)
        {
            fixture.NationOne.TotalGoalsFor += fixture.NationOneScore;
            fixture.NationTwo.TotalGoalsFor += fixture.NationTwoScore;
            fixture.NationOne.GroupStageGoalsFor += fixture.NationOneScore;
            fixture.NationTwo.GroupStageGoalsFor += fixture.NationTwoScore;

            //Goals against
            fixture.NationOne.TotalGoalsAgainst += fixture.NationTwoScore;
            fixture.NationTwo.TotalGoalsAgainst += fixture.NationOneScore;
            fixture.NationOne.GroupStageGoalsAgainst += fixture.NationTwoScore;
            fixture.NationTwo.GroupStageGoalsAgainst += fixture.NationOneScore;

            //Goal Difference
            fixture.NationOne.TotalGoalsDifference = fixture.NationOne.TotalGoalsFor - fixture.NationOne.TotalGoalsAgainst;
            fixture.NationTwo.TotalGoalsDifference = fixture.NationTwo.TotalGoalsFor - fixture.NationTwo.TotalGoalsAgainst;
            fixture.NationOne.GroupStageGoalsDifference = fixture.NationOne.GroupStageGoalsFor - fixture.NationOne.GroupStageGoalsAgainst;
            fixture.NationTwo.GroupStageGoalsDifference = fixture.NationTwo.GroupStageGoalsFor - fixture.NationTwo.GroupStageGoalsAgainst;
        }

        private void UpdateNationMatchStats(Fixture fixture)
        {
            //if (fixtureService.IsGroupFixture(fixture)){
                fixture.NationOne.MatchesPlayed++;
                fixture.NationTwo.MatchesPlayed++;

                if (fixture.Winner == fixture.NationOne)
                {
                    fixture.NationOne.Wins++;
                    fixture.NationTwo.Loses++;

                    fixture.NationOne.Points += 3;
                }
                else if (fixture.Winner == fixture.NationTwo)
                {
                    fixture.NationTwo.Wins++;
                    fixture.NationOne.Loses++;

                    fixture.NationTwo.Points += 3;
                }
                else
                {
                    fixture.NationOne.Draws++;
                    fixture.NationTwo.Draws++;

                    fixture.NationOne.Points++;
                    fixture.NationTwo.Points++;
                }
            //}
        }

        private void AssignWinnerToFixture(Fixture fixture)
        {
            if (fixture.NationOneScore > fixture.NationTwoScore)
            {
                fixture.Winner = fixture.NationOne;
            }
            else if (fixture.NationOneScore < fixture.NationTwoScore)
            {
                fixture.Winner = fixture.NationTwo;
            }
            else
            {
                return;
            }
        }

        public void PlayKnockoutRound(List<Fixture> fixtures)
        {
            foreach (Fixture fixture in fixtures)
            {
                PlayKnockoutFixture(fixture);
            }
        }

        public void SimulateGroupStageRound()
        {
            string[] groupLetters = new string[] { "A", "B", "C", "D", "E", "F", "G", "H" };
            int roundToSimulate = tournamentService.GetTournamentRound();
            foreach (string letter in groupLetters)
            {
                List<Fixture> roundFixtures = fixtureService.GetFixturesByRound($"{letter}-{roundToSimulate}");
                foreach (Fixture fixture in roundFixtures)
                {
                    PlayNormalFixture(fixture);
                }
            }
            tournamentService.IncreaseRound();
        }

        public void SimulateGroupStageEntirely()
        {
            List<Group> groupsFromService = groupService.GetAllGroups();
            foreach (Group group in groupsFromService)
            {
                tournamentService.AddFixturesFromGroup(group);
            }

            foreach (Fixture fixture in fixtureService.GetAllGroupFixtures())
            {
                PlayNormalFixture(fixture);
            }
        }

        public void SimulateKnockoutStageEntirely()
        {
            string tournamentRound = tournamentService.GetKnockoutRound();
            while (tournamentRound != "Final")
            {
                PlayKnockoutRound(fixtureService.GetFixturesByRound(tournamentRound));
                tournamentService.AdvanceKnockoutRounds(fixtureService.GetFixturesByRound(tournamentRound));
                tournamentService.IncreaseRound();
                tournamentRound = tournamentService.GetKnockoutRound();
            }
            PlayKnockoutRound(fixtureService.GetFixturesByRound(tournamentRound));
            PlayKnockoutRound(fixtureService.GetFixturesByRound("Third Place"));
        }

        public void SimulateEntireTournament()
        {
            SimulateGroupStageEntirely();
            TournamentService.tournamentRound = 4;
            tournamentService.SeedRoundOf16();
            SimulateKnockoutStageEntirely();
        }
    }
}
