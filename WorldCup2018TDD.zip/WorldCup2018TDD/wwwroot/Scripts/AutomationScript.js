﻿//Set up Variables 
document.querySelector('#automationToggle').checked = localStorage.getItem('automationToggleValue') === "false" ? false : true;
var automationToggleValue = document.querySelector('#automationToggle').checked;
var originalClassName = "table table-bordered table-responsive";
var simmingNotices = document.getElementsByClassName("simmingNotice");
var groupTables = document.getElementsByClassName("table");

//Main
if (automationToggleValue === true) {

    SetUpUIForAutomation();
}
else {
    TearDownUIFromAutomation();
}
document.getElementById('automationToggle').addEventListener("change", function () {
    automationToggleValue = document.querySelector('#automationToggle').checked;
    localStorage.setItem("automationToggleValue", automationToggleValue);
    if (automationToggleValue === true) {
        SetUpUIForAutomation();
    }
    else {
        TearDownUIFromAutomation();
    }
});

//Various Functions for Actions
function SetUpUIForAutomation() {
    document.getElementById('simulationButton').style.visibility = "hidden";
    HideSimmingNotices();
    ResetClassNamesForTables();
    setTimeout(function () {
        //Secondary check to see if the user has switched off the toggle while during timeout
        if (automationToggleValue) {
            ApplyBlurToTables();
            ShowSimmingNotices();
        }
    }, 3000)
    setTimeout(function () {
         //Secondary check to see if the user has switched off the toggle while during timeout
        if (automationToggleValue) {
            document.getElementById('simulationButton').click();
        }
    }, 5000);
}

function ShowSimmingNotices() {
    Array.prototype.forEach.call(simmingNotices, function (notice) {
        notice.style.visibility = "visible";
    });
}

function ApplyBlurToTables() {
    Array.prototype.forEach.call(groupTables, function (table) {
        table.className += " simming";
    });
}

function TearDownUIFromAutomation() {
    document.getElementById('simulationButton').style.visibility = "visible";
    ResetClassNamesForTables();
    HideSimmingNotices();
}

function HideSimmingNotices() {
    Array.prototype.forEach.call(simmingNotices, function (notice) {
        notice.style.visibility = "hidden";
    });
}

function ResetClassNamesForTables() {
    Array.prototype.forEach.call(groupTables, function (table) {
        table.className = originalClassName;
    });
}