﻿var GenerateNavBar = GenerateNavBar || (function () {
    var recentRound = {};

    return {
        init: function (Args) {
            recentRound = Args;
        },
        populateNavList: function () {
            var stageList = document.getElementById("listOfRounds");
            if (recentRound >= 0) {
                AddStageLinkToStageList("Group Stage", "/Group/GroupStage", "groupStageLink");
            }
            if (recentRound >= 4) {
                AddStageLinkToStageList("Knockout Stage", "/Knockout/KnockoutStage", "knockoutStageLink");
            }
            if (recentRound >= 8) {
                AddStageLinkToStageList("Simulation Breakdown", "/SimulationBreakdown/SimulationBreakdown", "simulationBreakdownLink");
            }

            function AddStageLinkToStageList(stageName, stageHref, stageLinkId) {
                var stageListItem = document.createElement("LI");
                var stageAnchor = document.createElement("A");
                var icon = document.createElement("I");
                icon.setAttribute("class", "fas fa-arrow-right");
                var stageText = document.createTextNode(" " + stageName);
                var anchor = document.createElement("a");
                console.log(stageAnchor);
                anchor.setAttribute('href', stageHref);
                anchor.appendChild(icon);
                anchor.appendChild(stageText);
                stageListItem.setAttribute("id", stageLinkId);
                stageListItem.appendChild(anchor);
                stageList.appendChild(stageListItem);
            }
        }
    };
}());

var HighlightCurrentStage = HighlightCurrentStage || (function () {
    var currentStage = {};
    return {
        init: function (Args) {
            currentStage = Args;
        },
        highlightStage: function () {
            switch (currentStage) {
                case "Group Stage":
                    var currentStageLink = document.getElementById("groupStageLink");
                    currentStageLink.classList.add("active");
                    break;
                case "Knockout Stage":
                    var currentStageLink = document.getElementById("knockoutStageLink");
                    currentStageLink.classList.add("active");
                    break;
                case "Simulation Breakdown":
                    var currentStageLink = document.getElementById("simulationBreakdownLink");
                    currentStageLink.classList.add("active");
                    break;
                default:
                    console.log("No stage Link found");
            }
        }
    };
}());
