﻿var HighlightWinnersPath = HighlightWinnersPath || (function () {
    var winner = {};

    return {
        init: function (Args) {
            winner = Args;
        },
        highlightPath: function () {
            var winnersBranchesNodeList = document.getElementsByClassName(winner);
            AddClassNameToBranches(winnersBranchesNodeList);
        }
    };
}());

function AddClassNameToBranches(winnersBranchesNodeList) {
    Array.prototype.forEach.call(winnersBranchesNodeList, function (branch) {
        branch.className += " winnersBranch";
    });
}
