﻿const pressed = [];
const secretCode = 'solid';
window.addEventListener('keyup', (e) => {
    pressed.push(e.key);
    pressed.splice(-secretCode.length - 1, pressed.length - secretCode.length);
    if (pressed.join('').includes(secretCode)) {
        window.open('http://tiny-giant-books.com/img/Uncle-Bob-Transparent-Background.png');
    }
});