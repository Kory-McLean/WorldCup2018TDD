﻿using System.Collections.Generic;
using System.Linq;
using WorldCup2018TDD.Data.Entities;

namespace WorldCup2018TDD.Data.Repositories
{
    public class NationRepository : INationRepository
    {
        private readonly WorldCupTDDDbContext dbContext;

        public NationRepository(WorldCupTDDDbContext dbContext)
        {
           this.dbContext = dbContext;
        }
        public List<Nation> GetAllNations()
        {
            return dbContext.Nations.OrderBy(n => n.Ranking).ToList();
        }

        public List<Nation> GetHighestScorers(int count)
        {
            return dbContext.Nations.OrderByDescending(n => n.TotalGoalsFor).Take(count).ToList();
        }

        public Nation GetNationByName(string name)
        {
            return dbContext.Nations.Where(n => n.Name == name).First();
        }

        public List<Nation> GetNationsByGroup(string groupLetter)
        {
            return dbContext.Nations.Where(n => n.GroupLetter == groupLetter).ToList();
        }

        public List<Nation> GetWorstDefences(int count)
        {
            return dbContext.Nations.OrderByDescending(n => n.TotalGoalsAgainst).Take(count).ToList();
        }

        public void ResetStats()
        {
            foreach (Nation nation in dbContext.Nations)
            {
                nation.Wins = 0;
                nation.Loses = 0;
                nation.Draws = 0;
                nation.TotalGoalsFor = 0;
                nation.GroupStageGoalsFor = 0;
                nation.TotalGoalsAgainst = 0;
                nation.GroupStageGoalsAgainst = 0;
                nation.TotalGoalsDifference = 0;
                nation.GroupStageGoalsDifference = 0;
                nation.MatchesPlayed = 0;
                nation.Points = 0;
            }
            dbContext.SaveChanges();
        }
    }
}
