﻿using System.Collections.Generic;
using WorldCup2018TDD.Data.Entities;

namespace WorldCup2018TDD.Data.Repositories
{
    public interface INationRepository
    {
        List<Nation> GetAllNations();
        Nation GetNationByName(string name);
        List<Nation> GetNationsByGroup(string groupLetter);
        void ResetStats();
        List<Nation> GetHighestScorers(int count);
        List<Nation> GetWorstDefences(int count);
    }
}
