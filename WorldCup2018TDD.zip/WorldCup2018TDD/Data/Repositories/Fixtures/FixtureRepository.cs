﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using WorldCup2018TDD.Data.Entities;

namespace WorldCup2018TDD.Data.Repositories.Fixtures
{
    public class FixtureRepository : IFixtureRepository
    {
        private readonly WorldCupTDDDbContext dbContext;

        public FixtureRepository(WorldCupTDDDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public void AddFixturesToDb(List<Fixture> fixturesToAdd)
        {
            foreach (Fixture fixture in fixturesToAdd)
            {
                dbContext.Add(fixture);
            }
            dbContext.SaveChanges();
        }

        public Fixture GetFixtureById(int id)
        {
            return dbContext.Fixtures.Where(f => f.Id == id)
                .Include(f => f.NationOne)
                .Include(f => f.NationTwo)
                .Include(f => f.Round)
                .First();
        }

        public List<Fixture> GetFixturesByRound(string round)
        {
            return dbContext.Fixtures.Where(f => f.Round == round)
               .Include(f => f.NationOne)
               .Include(f => f.NationTwo)
               .ToList();
        }

        public List<List<Fixture>> GetFixturesByRoundNumber(int roundNumber)
        {
            List<List<Fixture>> resultFixtures = new List<List<Fixture>>();
            string[] groupLetters = new string[] { "A", "B", "C", "D", "E", "F", "G", "H" };
            for (int i = 0; i < groupLetters.Length; i++)
            {
                resultFixtures.Add(GetFixturesByRound($"{groupLetters[i]}-{roundNumber}"));
            }
            return resultFixtures;
        }

        public List<Fixture> GetHighestScoringMatches(int count)
        {
            return dbContext.Fixtures.OrderByDescending(f => (f.NationOneScore + f.NationTwoScore))
                .Include(f => f.NationOne)
                .Include(f => f.NationTwo)
                .Take(count)
                .ToList();
        }

        public List<Fixture> GetHighestWinningMargins(int count)
        {
            return dbContext.Fixtures
                .Include(f => f.NationOne)
                .Include(f => f.NationTwo)
                .OrderByDescending(f => GetWinningMargin(f))
                .Take(count)
                .ToList();
        }

        private decimal GetWinningMargin(Fixture fixture)
        {
            return Math.Abs(fixture.NationOneScore - fixture.NationTwoScore);
        }

        public void ResetFixtures()
        {
            List<Fixture> fixtures = dbContext.Fixtures.ToList();
            dbContext.Fixtures.RemoveRange(fixtures);
            dbContext.SaveChanges();
        }

        public void SaveChanges()
        {
            dbContext.SaveChanges();
        }

        public List<Fixture> GetAllGroupFixtures()
        {
            return dbContext.Fixtures.Where(f => IsGroupFixture(f)).ToList();
        }
        public bool IsGroupFixture(Fixture testFixture)
        {
            List<string> groupLetters = new List<string>() { "A", "B", "C", "D", "E", "F", "G", "H" };
            foreach (string letter in groupLetters)
            {
                if (testFixture.Round.Contains($"{letter}-"))
                {
                    return true;
                }
            }
            return false;
        }
    }
}
