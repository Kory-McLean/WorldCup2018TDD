﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using WorldCup2018TDD.Data.Entities;

namespace WorldCup2018TDD.Data.Repositories
{
    public class GroupRepository : IGroupRepository
    {
        private readonly WorldCupTDDDbContext dbContext;

        public GroupRepository(WorldCupTDDDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public void AddGroup(Group groupToAdd)
        {
            dbContext.Groups.Add(groupToAdd);
            dbContext.SaveChanges();
        }

        public void AddGroups(List<Group> groups)
        {
            foreach (Group group in groups)
            {
                dbContext.Groups.Add(group);
            }
            dbContext.SaveChanges();
        }

        public List<Group> GetAllGroups()
        {
            return dbContext.Groups.Include(n => n.NationOne)
                              .Include(n => n.NationTwo)
                              .Include(n => n.NationThree)
                              .Include(n => n.NationFour)
                              .ToList().OrderBy(g => g.Letter).ToList();
        }

        public Group GetGroupByLetter(string letter)
        {
            return dbContext.Groups.Where(g => g.Letter == letter)
                .Include(g => g.NationOne)
                .Include(g => g.NationTwo)
                .Include(g => g.NationThree)
                .Include(g => g.NationFour)
                .First();
        }

        public bool AreThereGroups()
        {
            return dbContext.Groups.Any();
        }

        public void ResetGroups()
        {
            List<Group> groups = dbContext.Groups.ToList();
            dbContext.Groups.RemoveRange(groups);
            dbContext.SaveChanges();
        }
    }
}
