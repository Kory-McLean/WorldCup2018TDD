﻿using System.Collections.Generic;
using WorldCup2018TDD.Data.Entities;

namespace WorldCup2018TDD.Data.Repositories
{
    public interface IGroupRepository
    {
        List<Group> GetAllGroups();
        Group GetGroupByLetter(string letter);
        void AddGroup(Group groupToAdd);
        bool AreThereGroups();
        void ResetGroups();
        void AddGroups(List<Group> groups);
    }
}
