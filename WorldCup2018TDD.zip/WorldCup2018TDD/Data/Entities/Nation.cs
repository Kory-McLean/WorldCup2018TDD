﻿namespace WorldCup2018TDD.Data.Entities
{
    public class Nation
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Championships { get; set; }
        public int Ranking { get; set; }
        public string Confederation { get; set; }
        public int MatchesPlayed { get; set; }
        public int Wins { get; set; }
        public int Draws { get; set; }
        public int Loses { get; set; }
        public int TotalGoalsFor { get; set; }
        public int GroupStageGoalsFor { get; set; }
        public int TotalGoalsAgainst { get; set; }
        public int GroupStageGoalsAgainst { get; set; }
        public int TotalGoalsDifference { get; set; }
        public int GroupStageGoalsDifference { get; set; }
        public int Points { get; set; }
        public string GroupLetter { get; set; }
    }
}
