﻿namespace WorldCup2018TDD.Data.Entities
{
    public class Fixture
    {
        public int Id { get; set; }
        public Nation NationOne { get; set; }
        public Nation NationTwo { get; set; }
        public Nation Winner { get; set; }
        public int NationOneScore { get; set; }
        public int NationTwoScore { get; set; }
        public string Round { get; set; }
    }
}
