﻿namespace WorldCup2018TDD.Data.Entities
{
    public class Group
    {
        public int Id { get; set; }
        public string Letter { get; set; }
        public Nation NationOne { get; set; }
        public Nation NationTwo { get; set; }
        public Nation NationThree { get; set; }
        public Nation NationFour { get; set; }
    }
}
