﻿using Microsoft.EntityFrameworkCore;
using WorldCup2018TDD.Data.Entities;

namespace WorldCup2018TDD.Data
{
    public class WorldCupTDDDbContext : DbContext
    {
        public WorldCupTDDDbContext(DbContextOptions<WorldCupTDDDbContext> options) : base(options) { }

        public DbSet<Nation> Nations { get; set; }
        public DbSet<Fixture> Fixtures { get; set; }
        public DbSet<Group> Groups { get; set; }
    }
}
