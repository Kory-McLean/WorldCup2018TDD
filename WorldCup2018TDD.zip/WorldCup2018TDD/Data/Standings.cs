﻿using System.Collections.Generic;
using WorldCup2018TDD.Data.Entities;

namespace WorldCup2018TDD.Data
{
    //Just a place holder really for easier reading
    public class Standings
    {
        private List<Nation> standingsList;
        public Standings(List<Nation> standingsList)
        {
            this.standingsList = standingsList;
        }

        public List<Nation> GetStandings()
        {
            return standingsList;
        }
    } 
}
