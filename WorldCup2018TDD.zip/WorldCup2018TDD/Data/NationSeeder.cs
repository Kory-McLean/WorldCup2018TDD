﻿using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using WorldCup2018TDD.Data.Entities;

namespace WorldCup2018TDD.Data
{
    public class NationSeeder
    {
        private readonly WorldCupTDDDbContext dbContext;
        private readonly IHostingEnvironment hosting;

        public NationSeeder(WorldCupTDDDbContext dbContext, IHostingEnvironment hosting)
        {
            this.dbContext = dbContext;
            this.hosting = hosting;
        }

        public void Seed()
        {
            dbContext.Database.EnsureCreated();
            if (!dbContext.Nations.Any())
            {
                var filePath = Path.Combine(hosting.ContentRootPath, "Data/nations.json");
                var json = File.ReadAllText(filePath);
                var nations = JsonConvert.DeserializeObject<IEnumerable<Nation>>(json);
                dbContext.Nations.AddRange(nations);
                dbContext.SaveChanges();
            }
        }
    }
}
