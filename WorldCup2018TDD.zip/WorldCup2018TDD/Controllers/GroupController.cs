﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using WorldCup2018TDD.Data;
using WorldCup2018TDD.Data.Entities;
using WorldCup2018TDD.Services;
using WorldCup2018TDD.Services.Fixtures;
using WorldCup2018TDD.Services.Simulations;
using WorldCup2018TDD.Services.Tournaments;
using WorldCup2018TDD.ViewModels;

namespace WorldCup2018TDD.Controllers
{
    public class GroupController : Controller
    {
        private GroupService groupService;
        private TournamentService tournamentService;
        private SimulationService simulationService;
        private FixtureService fixtureService;

        public GroupController(WorldCupTDDDbContext dbContext)
        {
            groupService = new GroupService(dbContext);
            tournamentService = new TournamentService(dbContext);
            simulationService = new SimulationService(dbContext);
            fixtureService = new FixtureService(dbContext);
        }

        public IActionResult GroupStage()
        {
            GroupStageViewModel viewModel = new GroupStageViewModel()
            {
                Standings = GetStandingsForViewModel(),
                RecentRound = tournamentService.GetTournamentRound() - 1,
                RecentFixtures = fixtureService.GetFixturesByRoundNumber(tournamentService.GetTournamentRound() - 1),
                GroupLetters = new string[] { "A", "B", "C", "D", "E", "F", "G", "H" }
            };
            return View(viewModel);
        }

        private List<Standings> GetStandingsForViewModel()
        {
            List<Group> groupsFromService = groupService.GetAllGroups();
            List<Standings> standingsForView = new List<Standings>();
            foreach (Group group in groupsFromService)
            {
                Standings standingsToAdd = new Standings(tournamentService.GetStandingsFromGroup(group));
                tournamentService.AddFixturesFromGroup(group);
                standingsForView.Add(standingsToAdd);
            }
            return standingsForView;
        }

        public IActionResult Reset()
        {
            tournamentService.ResetTournament();
            return RedirectToAction("GroupStage");
        }

        public IActionResult SimulateGroupStageRound()
        {
            simulationService.SimulateGroupStageRound();
            return RedirectToAction("GroupStage");
        }

        public IActionResult SimulateWithRandomGroups()
        {
            tournamentService.ResetTournament();
            tournamentService.SeedRandomGroups();
            return RedirectToAction("GroupStage");
        }
    }
}
