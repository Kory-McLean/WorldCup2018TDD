﻿using Microsoft.AspNetCore.Mvc;

namespace WorldCup2018TDD.Controllers
{
    public class AppController : Controller
    {
        public IActionResult Index()
        { 
            ViewBag.Title = "Welcome!";
            return View();
        }
    }
}
