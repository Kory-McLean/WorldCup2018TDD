﻿using Microsoft.AspNetCore.Mvc;
using WorldCup2018TDD.Data;
using WorldCup2018TDD.Services;

namespace WorldCup2018TDD.Controllers
{
    public class NationController : Controller
    {
        private NationService nationService;

        public NationController(WorldCupTDDDbContext dbContext)
        {
            nationService = new NationService(dbContext);
        }
        public IActionResult Nations()
        {
            ViewBag.Title = "All Competeing Nations";
            return View(nationService.GetAllNations());
        }
    }
}
