﻿using Microsoft.AspNetCore.Mvc;
using WorldCup2018TDD.Data;
using WorldCup2018TDD.Services;
using WorldCup2018TDD.Services.Tournaments;

namespace WorldCup2018TDD.Controllers
{
    public class SimulationController : Controller
    {
        private TournamentService tournamentService;
        private GroupService groupService;

        public SimulationController(WorldCupTDDDbContext dbContext)
        {
            tournamentService = new TournamentService(dbContext);
            groupService = new GroupService(dbContext);
        }
        public IActionResult SimulationGroupDecision()
        {
            ViewBag.Title = "Please Select Group Seeding Method";
            return View();
        }

        public IActionResult SimulationTypeDecision()
        {
            ViewBag.Title = "Please Select Your Desired Simulation Type";
            return View();
        }

        public IActionResult SimulateWithActualGroups()
        {
            tournamentService.ResetTournament();
            groupService.PopulateGroups();
            return RedirectToAction("SimulationTypeDecision");
        }

        public IActionResult SimulateWithRandomGroups()
        {
            tournamentService.ResetTournament();
            tournamentService.SeedRandomGroups();
            return RedirectToAction("SimulationTypeDecision");
        }
    }
}
