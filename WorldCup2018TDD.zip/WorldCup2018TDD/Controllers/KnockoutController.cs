﻿using Microsoft.AspNetCore.Mvc;
using WorldCup2018TDD.Data;
using WorldCup2018TDD.Services;
using WorldCup2018TDD.Services.Fixtures;
using WorldCup2018TDD.Services.Simulations;
using WorldCup2018TDD.Services.Tournaments;
using WorldCup2018TDD.ViewModels;

namespace WorldCup2018TDD.Controllers
{
    public class KnockoutController : Controller
    {
        private GroupService groupService;
        private TournamentService tournamentService;
        private SimulationService simulationService;
        private FixtureService fixtureService;

        public KnockoutController(WorldCupTDDDbContext dbContext)
        {
            groupService = new GroupService(dbContext);
            tournamentService = new TournamentService(dbContext);
            simulationService = new SimulationService(dbContext);
            fixtureService = new FixtureService(dbContext);
        }

        public IActionResult KnockoutStage()
        {
            KnockoutStageViewModel viewModel = new KnockoutStageViewModel() {
                RoundOf16 = fixtureService.GetFixturesByRound("Round of 16"),
                QuarterFinals = fixtureService.GetFixturesByRound("Quarter Final"),
                SemiFinals = fixtureService.GetFixturesByRound("Semi Final"),
                ThirdPlace = fixtureService.GetFixturesByRound("Third Place"),
                Final = fixtureService.GetFixturesByRound("Final"),
                CurrentRound = tournamentService.GetTournamentRound(),
                CurrentKnockoutStage = tournamentService.GetKnockoutRound()
            };
            return View(viewModel);
        }

        public IActionResult SeedRoundOf16()
        {
            if(tournamentService.GetTournamentRound() == 4)
            {
                tournamentService.SeedRoundOf16();
            }
            return RedirectToAction("Knockoutstage");
        }

        public IActionResult SimulateKnockoutStageRound()
        {
            string tournamentRound = tournamentService.GetKnockoutRound();
            if (tournamentRound == "Final")
            {
                simulationService.PlayKnockoutRound(fixtureService.GetFixturesByRound("Third Place"));
            }
            simulationService.PlayKnockoutRound(fixtureService.GetFixturesByRound(tournamentRound));
            tournamentService.AdvanceKnockoutRounds(fixtureService.GetFixturesByRound(tournamentRound));
            tournamentService.IncreaseRound();
            return RedirectToAction("KnockoutStage");
        }

    }
}
