﻿using Microsoft.AspNetCore.Mvc;
using WorldCup2018TDD.Data;
using WorldCup2018TDD.Services;
using WorldCup2018TDD.Services.Fixtures;
using WorldCup2018TDD.Services.Simulations;
using WorldCup2018TDD.Services.Tournaments;
using WorldCup2018TDD.ViewModels;

namespace WorldCup2018TDD.Controllers
{
    public class SimulationBreakdownController : Controller
    {
        private GroupService groupService;
        private NationService nationService;
        private TournamentService tournamentService;
        private SimulationService simulationService;
        private FixtureService fixtureService;

        public SimulationBreakdownController(WorldCupTDDDbContext dbcContext)
        {
            groupService = new GroupService(dbcContext);
            tournamentService = new TournamentService(dbcContext);
            simulationService = new SimulationService(dbcContext);
            fixtureService = new FixtureService(dbcContext);
            nationService = new NationService(dbcContext);
        }

        public IActionResult SimulationBreakdown()
        {
            var i = tournamentService.GetTournamentRound();

            SimulationBreakdownViewModel viewModel = new SimulationBreakdownViewModel() {
                CurrentRound = tournamentService.GetTournamentRound(),
                TopFourNations = tournamentService.GetTopFourNations(),
                TopFiveHighestScorers = nationService.GetHighestScorers(5),
                TopFiveHighestScoringMatches = fixtureService.GetHighestScoringMatches(5),
                TopFiveHighestWinningMargins = fixtureService.GetHighestWinningMargins(5),
                FiveWorstDefences = nationService.GetWorstDefences(5)
            };
            return View(viewModel);
        }

        public IActionResult SimulateEntireTournament()
        {
            simulationService.SimulateEntireTournament();
            tournamentService.IncreaseRound();

            return RedirectToAction("SimulationBreakdown");
        }
    }
}
