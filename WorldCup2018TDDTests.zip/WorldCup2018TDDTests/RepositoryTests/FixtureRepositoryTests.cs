﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Shouldly;
using WorldCup2018TDD.Data.Entities;

namespace WorldCup2018TDDTests.RepositoryTests
{
    [TestClass]
    public class FixtureRepositoryTests
    {
        //This is used to test the helper functions which are used by the repository, The code here will be identical to that inside the repository
        [TestMethod]
        public void GetWinningMargin_Should_ReturnTheWinningMarginFromTheFixture()
        {
            //Arrange
            Nation nationOne = new Nation() { Name = "TestOne"};
            Nation nationTwo = new Nation() { Name = "TestTwo" };

            Fixture testFixtureTied_Zero = new Fixture() { NationOneScore = 0, NationTwoScore = 0, NationOne = nationOne, NationTwo = nationTwo };
            Fixture testFixtureTied_NonZero = new Fixture() { NationOneScore = 5, NationTwoScore = 5, NationOne = nationOne, NationTwo = nationTwo };
            Fixture testFixtureNationOneWin_CleanSheet = new Fixture() { NationOneScore = 5, NationTwoScore =  0, Winner = nationOne, NationOne = nationOne, NationTwo = nationTwo};
            Fixture testFixtureNationTwoWin_CleanSheet = new Fixture() { NationOneScore = 0, NationTwoScore = 5, Winner = nationTwo, NationOne = nationOne, NationTwo = nationTwo };
            Fixture testFixtureNationOneWin_Conceeded = new Fixture() { NationOneScore = 5, NationTwoScore = 3, Winner = nationOne, NationOne = nationOne, NationTwo = nationTwo };
            Fixture testFixtureNationTwoWin_Conceeded = new Fixture() { NationOneScore = 3, NationTwoScore = 5, Winner = nationTwo, NationOne = nationOne, NationTwo = nationTwo };


            //Act
            int resultTied_Zero = GetWinningMargin(testFixtureTied_Zero);
            int resultTied_NonZero = GetWinningMargin(testFixtureTied_NonZero);
            int resultNationOneWin_CleanSheet = GetWinningMargin(testFixtureNationOneWin_CleanSheet);
            int resultNationTwoWin_CleanSheet = GetWinningMargin(testFixtureNationTwoWin_CleanSheet);
            int resultNationOneWin_Conceeded = GetWinningMargin(testFixtureNationOneWin_Conceeded);
            int resultNationTwoWin_Conceeded = GetWinningMargin(testFixtureNationTwoWin_Conceeded);


            //Assert
            resultTied_Zero.ShouldBe(0);
            resultTied_NonZero.ShouldBe(0);
            resultNationOneWin_CleanSheet.ShouldBe(5);
            resultNationTwoWin_CleanSheet.ShouldBe(5);
            resultNationOneWin_Conceeded.ShouldBe(2);
            resultNationTwoWin_Conceeded.ShouldBe(2);
        }

        [TestMethod]
        public void IsGroupFixture_Should_ReturnTrueIfTheFixtureIsAGroupFixture()
        {
            //Arrange
            //Test Fixtures
            Fixture testFixture1 = new Fixture() { Round = "A-2" };
            Fixture testFixture2 = new Fixture() { Round = "Semi Final" };
            Fixture testFixture3 = new Fixture() { Round = "E-2" };
            Fixture testFixture4 = new Fixture() { Round = "Z-2" };

            //Act
            bool result1 = IsGroupFixture(testFixture1);
            bool result2 = IsGroupFixture(testFixture2);
            bool result3 = IsGroupFixture(testFixture3);
            bool result4 = IsGroupFixture(testFixture4);

            //Assert
            result1.ShouldBeTrue();
            result2.ShouldBeFalse();
            result3.ShouldBeTrue();
            result4.ShouldBeFalse();
        }

        private bool IsGroupFixture(Fixture testFixture)
        {
            List<string> groupLetters = new List<string>() { "A", "B", "C", "D", "E", "F", "G", "H" };
            foreach (string letter in groupLetters)
            {
                if (testFixture.Round.Contains($"{letter}-"))
                {
                    return true;
                }
            }
            return false;
        }

        private int GetWinningMargin(Fixture fixture)
        {
            return fixture.NationOne == fixture.Winner ? fixture.NationOneScore - fixture.NationTwoScore : fixture.NationTwoScore - fixture.NationOneScore;
        }

        
    }
}
