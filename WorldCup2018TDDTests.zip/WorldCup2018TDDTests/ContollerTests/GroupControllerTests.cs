﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Shouldly;
using System.Collections.Generic;
using WorldCup2018TDD.Data;
using WorldCup2018TDD.Data.Entities;
using WorldCup2018TDD.Data.Repositories;
using WorldCup2018TDD.Services;
using WorldCup2018TDD.Services.Tournaments;

namespace WorldCup2018TDDTests.ContollerTests
{
    [TestClass]
    public class GroupControllerTests
    {
        private Mock<IGroupRepository> _groupRepositoryMock;
        private GroupService _groupService;
        private TournamentService _tournamentService;

        [TestInitialize]
        public void Init()
        {
            _groupRepositoryMock = new Mock<IGroupRepository>();
            _groupService = new GroupService(_groupRepositoryMock.Object);
            _tournamentService = new TournamentService(_groupService);
        }

        [TestMethod]
        public void GetStandingsForViewModel_Should_ReturnListOfStandingsSortedCorrectlyForEachGroup()
        {
            //Arrange 
            _groupRepositoryMock.Setup(o => o.GetAllGroups()).Returns(SetUpGetAllGroupsWithPointsAndGoalDifference(8));

            //Act 
            List<Standings> result = GetStandingsForViewModel();

            //Assert
            result.Count.ShouldBe(8);
            foreach (Standings standing in result)
            {
                standing.GetStandings().Count.ShouldBe(4);
                for (int i = 0; i + 1 < 4; i++)
                {
                    standing.GetStandings()[i].Points.ShouldBeGreaterThanOrEqualTo(standing.GetStandings()[i+1].Points);
                    if(standing.GetStandings()[i].Points == standing.GetStandings()[i + 1].Points)
                    {
                        standing.GetStandings()[i].TotalGoalsDifference.ShouldBeGreaterThanOrEqualTo(standing.GetStandings()[i+1].TotalGoalsDifference);
                    }
                }
            }
        }
        private List<Standings> GetStandingsForViewModel()
        {
            List<Group> groupsFromService = _groupService.GetAllGroups();
            List<Standings> standingsForView = new List<Standings>();
            foreach (Group group in groupsFromService)
            {
                Standings standingsToAdd = new Standings(_tournamentService.GetStandingsFromGroup(group));
                standingsForView.Add(standingsToAdd);
            }
            return standingsForView;
        }

        private List<Group> SetUpGetAllGroupsWithPointsAndGoalDifference(int count)
        {
            List<Group> result = new List<Group>();

            for (int i = 0; i < count; i++)
            {
                result.Add(new Group
                {
                    NationOne = new Nation() { Name = "Test1" , Points = 9},
                    NationTwo = new Nation() { Name = "Test2", Points = 6, TotalGoalsDifference = 5},
                    NationThree = new Nation() { Name = "Test3", Points = 6, TotalGoalsDifference = 4 },
                    NationFour = new Nation() { Name = "Test4", Points = 3 }
                });
            }
            return result;
        }
    }
}
