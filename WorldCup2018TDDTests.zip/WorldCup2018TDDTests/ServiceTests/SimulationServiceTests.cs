﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Shouldly;
using WorldCup2018TDD.Data.Entities;
using WorldCup2018TDD.Data.Repositories.Fixtures;
using WorldCup2018TDD.Services.Fixtures;
using WorldCup2018TDD.Services.Simulations;

namespace WorldCup2018TDDTests.ServiceTests
{
    [TestClass]
    public class SimulationServiceTests
    {
        private SimulationService _testee;
        private Mock<IFixtureRepository> _fixtureRepository;
        private IFixtureService _fixtureService;

        [TestInitialize]
        public void Init()
        {
            _fixtureRepository = new Mock<IFixtureRepository>();
            _fixtureService = new FixtureService(_fixtureRepository.Object);
            _testee = new SimulationService(_fixtureService);
        }
        
        [TestMethod]
        public void PlayNormalFixture_ShouldNot_Return()
        {
            //Arrange
            _fixtureRepository.Setup(o => o.GetFixtureById(5)).Returns(SetUpMockGetGroupFixtureById(5));
            Fixture testFixture = _fixtureService.GetFixtureById(5);

            //State before the game is played
            testFixture.Winner.ShouldBeNull();
            testFixture.NationOneScore.ShouldBe(0);
            testFixture.NationTwoScore.ShouldBe(0);

            //Act 
            _testee.PlayNormalFixture(testFixture);

            //Assert
            if (testFixture.Winner == testFixture.NationOne)
            {
                //Nation One Wins
                testFixture.NationOneScore.ShouldBeGreaterThan(testFixture.NationTwoScore);
                testFixture.NationOne.Points.ShouldBe(3);
                testFixture.NationTwo.Points.ShouldBe(0);
            }
            else if (testFixture.Winner == testFixture.NationTwo)
            {
                //Nation Two wins
                testFixture.NationTwoScore.ShouldBeGreaterThan(testFixture.NationOneScore);
                testFixture.NationTwo.Points.ShouldBe(3);
                testFixture.NationOne.Points.ShouldBe(0);
            }
            else
            {
                //Draw
                testFixture.NationOneScore.ShouldBe(testFixture.NationTwoScore);
                testFixture.NationOne.Points.ShouldBe(1);
                testFixture.NationTwo.Points.ShouldBe(1);
            }
            testFixture.NationOne.MatchesPlayed.ShouldBe(1);
            testFixture.NationTwo.MatchesPlayed.ShouldBe(1);

            testFixture.NationOne.TotalGoalsFor.ShouldBe(testFixture.NationOneScore);
            testFixture.NationTwo.TotalGoalsFor.ShouldBe(testFixture.NationTwoScore);

            testFixture.NationOne.TotalGoalsAgainst.ShouldBe(testFixture.NationTwoScore);
            testFixture.NationTwo.TotalGoalsAgainst.ShouldBe(testFixture.NationOneScore);
        }

        [TestMethod]
        public void PlayNormalMatchForGroupStage_ShouldNot_Return()
        {
            //Arrange
            _fixtureRepository.Setup(o => o.GetFixtureById(5)).Returns(SetUpMockGetGroupFixtureById(5));
            Fixture testFixture = _fixtureService.GetFixtureById(5);
            _fixtureRepository.Setup(o => o.IsGroupFixture(testFixture)).Returns(IsGroupFixtureMock(testFixture));


            //State before the game is played
            testFixture.Winner.ShouldBeNull();
            testFixture.NationOneScore.ShouldBe(0);
            testFixture.NationTwoScore.ShouldBe(0);
            testFixture.NationOne.GroupStageGoalsFor.ShouldBe(0);
            testFixture.NationTwo.GroupStageGoalsFor.ShouldBe(0);
            testFixture.NationOne.TotalGoalsFor.ShouldBe(0);
            testFixture.NationTwo.TotalGoalsFor.ShouldBe(0);

            //Act
            _testee.PlayNormalFixture(testFixture);

            //Assert
            testFixture.NationOne.GroupStageGoalsFor.ShouldBe(testFixture.NationOneScore);
            testFixture.NationTwo.GroupStageGoalsFor.ShouldBe(testFixture.NationTwoScore);
            testFixture.NationOne.TotalGoalsFor.ShouldBe(testFixture.NationOneScore);
            testFixture.NationTwo.TotalGoalsFor.ShouldBe(testFixture.NationTwoScore);
        }

        [TestMethod]
        public void SortOutNationStats_ForGroup_ShouldNot_Return()
        {
            //Arrange
            _fixtureRepository.Setup(o => o.GetFixtureById(5)).Returns(SetUpMockGetGroupFixtureById(5));
            Fixture testFixture = _fixtureService.GetFixtureById(5);

            //Act
            _testee.SortNationGoalStats(testFixture);

            //Assert
            testFixture.NationOne.GroupStageGoalsAgainst.ShouldBe(testFixture.NationTwoScore);
            testFixture.NationTwo.GroupStageGoalsAgainst.ShouldBe(testFixture.NationOneScore);

            testFixture.NationOne.GroupStageGoalsFor.ShouldBe(testFixture.NationOneScore);
            testFixture.NationTwo.GroupStageGoalsFor.ShouldBe(testFixture.NationTwoScore);

            testFixture.NationOne.TotalGoalsAgainst.ShouldBe(testFixture.NationTwoScore);
            testFixture.NationTwo.TotalGoalsAgainst.ShouldBe(testFixture.NationOneScore);

            testFixture.NationOne.TotalGoalsFor.ShouldBe(testFixture.NationOneScore);
            testFixture.NationTwo.TotalGoalsFor.ShouldBe(testFixture.NationTwoScore);
        }

        [TestMethod]
        public void SortOutNationStats_ForKnockout_ShouldNot_Return()
        {
            //Arrange
            _fixtureRepository.Setup(o => o.GetFixtureById(5)).Returns(SetUpMockGetKnockoutFixtureById(5));
            Fixture testFixture = _fixtureService.GetFixtureById(5);

            //Act
            _testee.SortNationGoalStats(testFixture);

            //Assert
            testFixture.NationOne.GroupStageGoalsAgainst.ShouldBe(0);
            testFixture.NationTwo.GroupStageGoalsAgainst.ShouldBe(0);

            testFixture.NationOne.GroupStageGoalsFor.ShouldBe(0);
            testFixture.NationTwo.GroupStageGoalsFor.ShouldBe(0);

            testFixture.NationOne.TotalGoalsAgainst.ShouldBe(testFixture.NationTwoScore);
            testFixture.NationTwo.TotalGoalsAgainst.ShouldBe(testFixture.NationOneScore);

            testFixture.NationOne.TotalGoalsFor.ShouldBe(testFixture.NationOneScore);
            testFixture.NationTwo.TotalGoalsFor.ShouldBe(testFixture.NationTwoScore);
        }

        [TestMethod]
        public void PlayExtraTime_ShouldNot_Return()
        {
            //Arrange
            _fixtureRepository.Setup(o => o.GetFixtureById(5)).Returns(SetUpMockGetGroupFixtureById(5));
            Fixture testFixture = _fixtureService.GetFixtureById(5);
            //Act
            _testee.PlayExtratime(testFixture);

            //Assert
            if (testFixture.Winner == testFixture.NationOne)
            {
                //Nation One Wins
                testFixture.NationOneScore.ShouldBeGreaterThan(testFixture.NationTwoScore);
            }
            else if (testFixture.Winner == testFixture.NationTwo)
            {
                //Nation Two wins
                testFixture.NationTwoScore.ShouldBeGreaterThan(testFixture.NationOneScore);
            }
            else
            {
                //Draw
                testFixture.NationOneScore.ShouldBe(testFixture.NationTwoScore);
            }

            testFixture.NationOne.MatchesPlayed.ShouldBe(0);
            testFixture.NationTwo.MatchesPlayed.ShouldBe(0);

            testFixture.NationOne.TotalGoalsFor.ShouldBe(testFixture.NationOneScore);
            testFixture.NationTwo.TotalGoalsFor.ShouldBe(testFixture.NationTwoScore);

            testFixture.NationOne.TotalGoalsAgainst.ShouldBe(testFixture.NationTwoScore);
            testFixture.NationTwo.TotalGoalsAgainst.ShouldBe(testFixture.NationOneScore);

            testFixture.NationOne.GroupStageGoalsAgainst.ShouldBe(0);
            testFixture.NationTwo.GroupStageGoalsAgainst.ShouldBe(0);

            testFixture.NationOne.GroupStageGoalsFor.ShouldBe(0);
            testFixture.NationTwo.GroupStageGoalsFor.ShouldBe(0);
        }

        [TestMethod]
        public void PlayPenalties_ShouldNot_Return()
        {
            //Arrange
            _fixtureRepository.Setup(o => o.GetFixtureById(5)).Returns(SetUpMockGetGroupFixtureById(5));
            Fixture testFixture = _fixtureService.GetFixtureById(5);
            //Act
            _testee.PlayPenalties(testFixture);

            //Assert
            testFixture.Winner.ShouldNotBeNull();

            testFixture.NationOne.MatchesPlayed.ShouldBe(0);
            testFixture.NationTwo.MatchesPlayed.ShouldBe(0);

            testFixture.NationOne.TotalGoalsFor.ShouldBe(testFixture.NationOneScore);
            testFixture.NationTwo.TotalGoalsFor.ShouldBe(testFixture.NationTwoScore);

            testFixture.NationOne.TotalGoalsAgainst.ShouldBe(testFixture.NationTwoScore);
            testFixture.NationTwo.TotalGoalsAgainst.ShouldBe(testFixture.NationOneScore);

            testFixture.NationOne.GroupStageGoalsAgainst.ShouldBe(0);
            testFixture.NationTwo.GroupStageGoalsAgainst.ShouldBe(0);

            testFixture.NationOne.GroupStageGoalsFor.ShouldBe(0);
            testFixture.NationTwo.GroupStageGoalsFor.ShouldBe(0);
        }

        [TestMethod]
        public void PlayKnockOutFixture_ShouldNot_Return()
        {
            //Arrange
            _fixtureRepository.Setup(o => o.GetFixtureById(5)).Returns(SetUpMockGetGroupFixtureById(5));
            Fixture testFixture = _fixtureService.GetFixtureById(5);
            testFixture.NationOne.MatchesPlayed.ShouldBe(0);
            //Act
            _testee.PlayKnockoutFixture(testFixture);

            //Assert
            testFixture.NationOne.MatchesPlayed.ShouldBe(0);
            testFixture.Winner.ShouldNotBeNull();

            testFixture.NationOne.GroupStageGoalsAgainst.ShouldBe(0);
            testFixture.NationTwo.GroupStageGoalsAgainst.ShouldBe(0);

            testFixture.NationOne.GroupStageGoalsFor.ShouldBe(0);
            testFixture.NationTwo.GroupStageGoalsFor.ShouldBe(0);

            testFixture.NationOne.TotalGoalsAgainst.ShouldBe(testFixture.NationTwoScore);
            testFixture.NationTwo.TotalGoalsAgainst.ShouldBe(testFixture.NationOneScore);

            testFixture.NationOne.TotalGoalsFor.ShouldBe(testFixture.NationOneScore);
            testFixture.NationTwo.TotalGoalsFor.ShouldBe(testFixture.NationTwoScore);
        }

        private Fixture SetUpMockGetGroupFixtureById(int id)
        {
            return new Fixture()
            {
                Id = id,
                NationOne = new Nation() { Name="Brazil", Ranking=2 },
                NationTwo = new Nation() { Name= "Germany", Ranking=1 },
                Round = "A-1"
            };
        }

        private Fixture SetUpMockGetKnockoutFixtureById(int id)
        {
            return new Fixture()
            {
                Id = id,
                NationOne = new Nation() { Name = "Brazil", Ranking = 2 },
                NationTwo = new Nation() { Name = "Germany", Ranking = 1 },
                Round = "Round of 16"
            };
        }

        public bool IsGroupFixtureMock(Fixture testFixture)
        {
            List<string> groupLetters = new List<string>() { "A", "B", "C", "D", "E", "F", "G", "H" };
            foreach (string letter in groupLetters)
            {
                if (testFixture.Round.Contains($"{letter}-"))
                {
                    return true;
                }
            }
            return false;
        }
    }
}
