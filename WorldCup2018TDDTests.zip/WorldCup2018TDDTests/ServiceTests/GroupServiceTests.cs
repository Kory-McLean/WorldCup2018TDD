﻿using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Shouldly;
using WorldCup2018TDD.Data.Entities;
using WorldCup2018TDD.Data.Repositories;
using WorldCup2018TDD.Services;

namespace WorldCup2018TDDTests.ServiceTests
{
    [TestClass]
    public class GroupServiceTests
    {
        private GroupService _testee;
        private Mock<IGroupRepository> _groupRepositoryMock;

        [TestInitialize]
        public void Init()
        {
            _groupRepositoryMock = new Mock<IGroupRepository>();
            _testee = new GroupService(_groupRepositoryMock.Object);
        }

        [TestMethod]
        public void GetAllGroups_Should_ReturnAllGroups()
        {
            //Arrange 
            _groupRepositoryMock.Setup(o => o.GetAllGroups()).Returns(SetUpGetAllGroups(8));

            //Action
            var result = _testee.GetAllGroups();

            //Assert
            result.Count.ShouldBe(8);
        }

        [TestMethod]
        public void GetGroupByLetter_Should_ReturnGroupWithSpecifiedNumber()
        {
            //Arrange
            _groupRepositoryMock.Setup(o => o.GetGroupByLetter("A")).Returns(MockedGetSingleGroup("A"));

            //Action
            Group result = _testee.GetGroupByLetter("A");

            //Assert
            result.ShouldBeOfType<Group>();
            result.Letter.ShouldBe("A");
        }

        [TestMethod]
        public void AssignNationsToGroup_Should_ReturnsGroup_WithPropertiesFilled()
        {
            //Arrange
            Mock<INationRepository> _nationRepositoryMock = new Mock<INationRepository>();
            NationService _nationService = new NationService(_nationRepositoryMock.Object);
            _nationRepositoryMock.Setup(o => o.GetNationsByGroup("A")).Returns(SetUpGetNationsByGroup("A"));

            //Action
            Group result = _testee.AssignNationsToGroup(_nationService.GetNationsByGroup("A"), "A");

            //Assert
            result.Letter.ShouldBe("A");
        }


        private Group MockedGetSingleGroup(string letter)
        {
            return new Group() {
                Letter = letter,
                NationOne = new Nation() { Name = "Test1" },
                NationTwo = new Nation() { Name = "Test2" },
                NationThree = new Nation() { Name = "Test3" },
                NationFour = new Nation() { Name = "Test4" }
            };
        }

        private List<Group> SetUpGetAllGroups(int count)
        {
            List<Group> result = new List<Group>();

            for (int i = 0; i < count; i++)
            {
                result.Add(new Group {
                    NationOne = new Nation() { Name = "Test1" },
                    NationTwo = new Nation() { Name = "Test2" },
                    NationThree = new Nation() { Name = "Test3" },
                    NationFour = new Nation() { Name = "Test4" }
                });
            }
            return result;
        }
        private List<Nation> SetUpGetNationsByGroup(string letter)
        {
            List<Nation> result = new List<Nation>();
            for (int i = 0; i < 4; i++)
            {
                result.Add(new Nation()
                {
                    GroupLetter = letter
                });
            }
            return result;
        }
    }
}
