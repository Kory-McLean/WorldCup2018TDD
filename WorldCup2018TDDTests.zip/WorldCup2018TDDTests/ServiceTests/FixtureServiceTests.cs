﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Shouldly;
using WorldCup2018TDD.Data.Entities;
using WorldCup2018TDD.Data.Repositories.Fixtures;
using WorldCup2018TDD.Services.Fixtures;

namespace WorldCup2018TDDTests.ServiceTests
{
    [TestClass]
    public class FixtureServiceTests
    {
        private FixtureService _testee;
        private Mock<IFixtureRepository> _fixtureRepositoryMock;

        [TestInitialize]
        public void Init()
        {
            _fixtureRepositoryMock = new Mock<IFixtureRepository>();
            _testee = new FixtureService(_fixtureRepositoryMock.Object);
        }

        [TestMethod]
        public void GetFixtureById_Should_ReturnFixturewithCorrectId()
        {
            //Arrange 
            _fixtureRepositoryMock.Setup(o => o.GetFixtureById(5)).Returns(SetUpMockGetFixtureById(5));

            //Act
            Fixture result = _testee.GetFixtureById(5);

            //Assert
            result.Id.ShouldBe(5);
            result.NationOne.ShouldNotBeNull();
            result.NationTwo.ShouldNotBeNull();
        }

        [TestMethod]
        public void GetFixturesByRound_Should_ReturnListOfFixturesWhichRepresentARound()
        {
            //Arange
            _fixtureRepositoryMock.Setup(o => o.GetFixturesByRound("Group-1")).Returns(SetUpMockGetFixturesByRound("Group-1"));

            //Act 
            List<Fixture> result = _testee.GetFixturesByRound("Group-1");

            //Asssert
            foreach (Fixture fixture in result)
            {
                fixture.Round.ShouldBe("Group-1");
                fixture.NationOne.ShouldNotBeNull();
                fixture.NationTwo.ShouldNotBeNull();
            }
        }

        [TestMethod]
        public void GetRecentRoundMatches_Should_ReturnAListOfListOfFixtures()
        {
            //Arrange
            _fixtureRepositoryMock.Setup(o => o.GetFixturesByRoundNumber(1)).Returns(SetUpMockGetFixturesByRoundNumber(1));

            //Act
            List<List<Fixture>> result = _testee.GetFixturesByRoundNumber(1);

            //Assert
            foreach (List<Fixture> fixtures in result)
            {
                foreach (Fixture fixture in fixtures)
                {
                    fixture.Round.ShouldContain("1");
                }
            }
        
        }

        [TestMethod]
        public void GetAllGroupFixtures_Should_ReturnAListOfAllGroupFixtures()
        {
            //Arrange
            _fixtureRepositoryMock.Setup(o => o.GetAllGroupFixtures()).Returns(SetUpMockGetAllGroupFixtures());

            //Act 
            List<Fixture> result = _testee.GetAllGroupFixtures();

            //Assert
            result.Count.ShouldBe(48);
        }

        [TestMethod]
        public void IsGroupFixture_Should_ReturnBool()
        {
            //Arange
            Fixture testFixtureTrue = new Fixture()
            {
                Id = 1,
                NationOne = new Nation() { Name = "Brazil", Ranking = 2 },
                NationTwo = new Nation() { Name = "Germany", Ranking = 1 },
                Round = "A-1"
            };

            Fixture testFixtureFalse = new Fixture()
            {
                Id = 1,
                NationOne = new Nation() { Name = "Brazil", Ranking = 2 },
                NationTwo = new Nation() { Name = "Germany", Ranking = 1 },
                Round = "Round of 16"
            };
            _fixtureRepositoryMock.Setup(o => o.IsGroupFixture(testFixtureTrue)).Returns(IsGroupFixtureMock(testFixtureTrue));
            _fixtureRepositoryMock.Setup(o => o.IsGroupFixture(testFixtureFalse)).Returns(IsGroupFixtureMock(testFixtureFalse));

            //Act
            bool resultTrue = _testee.IsGroupFixture(testFixtureTrue);
            bool resultFalse = _testee.IsGroupFixture(testFixtureFalse);

            //Act
            resultTrue.ShouldBeTrue();
            resultFalse.ShouldBeFalse();
        }

        private List<Fixture> SetUpMockGetAllGroupFixtures()
        {
            List<Fixture> result = new List<Fixture>();
            for (int i = 0; i < 48; i++)
            {
                result.Add(new Fixture()
                {
                    Round = "Group",
                    NationOne = new Nation() { Name = $"Test {i}", Ranking = i},
                    NationTwo = new Nation() { Name = $"Test {i + 1}", Ranking = (i+ 1)}
                });
            }
            return result;
        }

        private List<List<Fixture>> SetUpMockGetFixturesByRoundNumber(int number)
        {
            List<List<Fixture>> fixtures = new List<List<Fixture>>();
            string[] groupLetter = new string[] { "A", "B", "C", "D", "E", "F", "G", "H" };
            for (int i = 0; i < groupLetter.Length; i++)
            {
                fixtures.Add(new List<Fixture>() {
                        new Fixture(){Round = $"{groupLetter[i]}-{number}" } });
            }
            return fixtures;
        }

        private List<Fixture> SetUpMockGetFixturesByRound(string round)
        {
            return new List<Fixture>() { new Fixture() {
                NationOne = new Nation(),
                NationTwo = new Nation(),
                Round = round
            },
            new Fixture() {
                NationOne = new Nation(),
                NationTwo = new Nation(),
                Round = round
                },
            new Fixture() {
                NationOne = new Nation(),
                NationTwo = new Nation(),
                Round = round
                }
            };
        }

        private Fixture SetUpMockGetFixtureById(int id)
        {
            return new Fixture() { Id = id,
            NationOne = new Nation(),
            NationTwo = new Nation()
            };
        }

        public bool IsGroupFixtureMock(Fixture testFixture)
        {
            List<string> groupLetters = new List<string>() { "A", "B", "C", "D", "E", "F", "G", "H" };
            foreach (string letter in groupLetters)
            {
                if (testFixture.Round.Contains($"{letter}-"))
                {
                    return true;
                }
            }
            return false;
        }
    }
}
