﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Shouldly;
using WorldCup2018TDD.Data.Entities;
using WorldCup2018TDD.Data.Repositories;
using WorldCup2018TDD.Data.Repositories.Fixtures;
using WorldCup2018TDD.Services;
using WorldCup2018TDD.Services.Fixtures;
using WorldCup2018TDD.Services.Tournaments;

namespace WorldCup2018TDDTests.ServiceTests
{
    [TestClass]
    public class TournamentServiceTests
    {
        private TournamentService _testee;
        private Mock<IGroupRepository> _groupRepositoryMock;
        private GroupService _groupService;
        private Mock<IFixtureRepository> _fixtureRepositoryMock;
        private FixtureService _fixtureService;
        private Mock<INationRepository> _nationRepositoryMock;
        private NationService _nationService;

        [TestInitialize]
        public void Init()
        {
            _groupRepositoryMock = new Mock<IGroupRepository>();
            _groupService = new GroupService(_groupRepositoryMock.Object);
            _testee = new TournamentService(_groupService);
            _fixtureRepositoryMock = new Mock<IFixtureRepository>();
            _fixtureService = new FixtureService(_fixtureRepositoryMock.Object);
            _nationRepositoryMock = new Mock<INationRepository>();
            _nationService = new NationService(_nationRepositoryMock.Object);

        }

        [TestMethod]
        public void GetFixturesFromGroup_Should_ReturnListOfFixtures()
        {
            //Arrange
            _groupRepositoryMock.Setup(o => o.GetGroupByLetter("A")).Returns(MockedGetSingleGroup("A"));

            //Act
            List<Fixture> result = _testee.GetFixturesFromGroup(_groupService.GetGroupByLetter("A"));

            //Assert
            result.Count.ShouldBe(6);
        }
            
        [TestMethod]
        public void GetGroupStandings_Should_ReturnOrderedListOfNations()
        {
            //Arrange 
            _groupRepositoryMock.Setup(o => o.GetGroupByLetter("A")).Returns(MockedGetSingleGroup("A"));

            //Act
            List<Nation> result = _testee.GetStandingsFromGroup(_groupService.GetGroupByLetter("A"));

            //Assert
            result.Count.ShouldBe(4);
            Nation currentNation = result[0];

            //Iterates over the standings and checks to see if they are ordered correctly

            for (int i = 0; i < 4; i++)
            {
                currentNation.Points.ShouldBeGreaterThanOrEqualTo(result[i].Points);
                if(currentNation.Points == result[i].Points)
                {
                    currentNation.TotalGoalsDifference.ShouldBeGreaterThanOrEqualTo(result[i].TotalGoalsDifference);
                }
            }
        }

        [TestMethod]
        public void GetGroupAdvancers_Should_ReturntheTopTwoTeamsInTheGroup()
        {
            //Arrange
            _groupRepositoryMock.Setup(o => o.GetGroupByLetter("A")).Returns(MockedGetSingleGroup("A"));

            //Act
            List<Nation> result = _testee.GetGroupAdvancers(_groupService.GetGroupByLetter("A"));

            //Assert
            result[0].Points.ShouldBeGreaterThanOrEqualTo(result[1].Points);
            result[0].Points.ShouldBe(9);
            result[1].Points.ShouldBe(6);
            result[1].GroupStageGoalsDifference.ShouldBe(1);
        }

        [TestMethod]
        public void GenerateSeedingDictionary_Should_ReturnADictionaryWhichMapsGroupLettersToAdvancers()
        {
            //Arrange
            _groupRepositoryMock.Setup(o => o.GetGroupByLetter("A")).Returns(MockedGetSingleGroup("A"));
            _groupRepositoryMock.Setup(o => o.GetGroupByLetter("B")).Returns(MockedGetSingleGroup("B"));

            //Act
            Dictionary<string, List<Nation>> result = _testee.GenerateSeedingDictionary(new List<string>() { "A", "B" });

            //Assert
            result["A"][0].Name.ShouldBe("Test1");
            result["B"][1].Points.ShouldBe(6);
            result["B"][1].GroupStageGoalsDifference.ShouldBe(1);
        }

        [TestMethod]
        public void GetNextRound_Should_ReturnTheNextRoundBasedOnParameter()
        {
            //Arrange
            string testStringOne = "Round of 16";
            string testStringTwo = "Quarter Final";

            //Act 
            string resultOne = _testee.GetNextRound(testStringOne);
            string resultTwo = _testee.GetNextRound(testStringTwo);

            //Assert 
            resultOne.ShouldBe("Quarter Final");
            resultTwo.ShouldBe("Semi Final");
        }

        [TestMethod]
        public void GetThirdPlaceFixture_Should_ReturnThirdPlaceFixture()
        {
            //Arrange
            _fixtureRepositoryMock.Setup(o => o.GetFixturesByRound("Semi Final")).Returns(SetUpGetFixturesByRoundMock("Semi Final"));

            //Act
            Fixture result = _testee.GetThirdPlaceMatch(_fixtureService.GetFixturesByRound("Semi Final"));

            //Assert
            result.NationOne.Name.ShouldBe("TestTwo");
            result.NationTwo.Name.ShouldBe("TestThree");
            result.Round.ShouldBe("Third Place");
        }

        [TestMethod]
        public void GetRandomIndex_Should_ReturnARandomIntBetween0And31()
        {
            //We will test the function 5 times
            //Act & Assert
            int result;
            for (int i = 0; i < 5; i++)
            {
                result = _testee.GetRandomIndex(32);
                result.ShouldBeGreaterThanOrEqualTo(0);
                result.ShouldBeLessThanOrEqualTo(31);
            }
        }

        [TestMethod]
        public void MakeRandomGroups_Should_ReturnEightRandomlyGeneratedGroups()
        {
            //Arrange 
            _nationRepositoryMock.Setup(o => o.GetAllNations()).Returns(SetUpNations(32));

            //Act
            List<Group> result = _testee.MakeRandomGroups(_nationService.GetAllNations());

            //Assert
            //Test The amount returned
            result.Count.ShouldBe(8);
            //Test that the letters are correct
            List<string> groupLetters = new List<string>() { "A", "B", "C", "D", "E", "F", "G", "H" };
            for (int i = 0; i < groupLetters.Count; i++)
            {
                result[i].Letter.ShouldBe(groupLetters[i]);
            }
            //Test that each nation is present
            //Arrange
            List<Nation> nationsFromResult = GetNationsFromGroups(result);
            List<Nation> nationsFromService = _nationService.GetAllNations();
            //Test Count
            nationsFromResult.Count.ShouldBe(32);
            foreach (Nation nation in nationsFromService)
            {
                nationsFromResult.ShouldContain(nation);
            }
        }

        private List<Nation> GetNationsFromGroups(List<Group> groups)
        {
            List<Nation> result = new List<Nation>();
            foreach (Group group in groups)
            {
                result.Add(group.NationOne);
                result.Add(group.NationTwo);
                result.Add(group.NationThree);
                result.Add(group.NationFour);
            }
            return result;
        }

        private List<Fixture> SetUpGetFixturesByRoundMock(string round)
        {
            Nation nationOne = new Nation() { Name="TestOne"};
            Nation nationTwo = new Nation() { Name = "TestTwo" };
            Nation nationThree = new Nation() { Name = "TestThree" };
            Nation nationFour= new Nation() { Name = "TestFour" };
            return new List<Fixture>() {
                new Fixture() {Round = round, NationOne = nationOne, NationTwo = nationTwo, Winner = nationOne },
                new Fixture() {Round = round, NationOne = nationThree, NationTwo = nationFour, Winner = nationFour }
            };
        }

        private Group MockedGetSingleGroup(string letter)
        {
            return new Group()
            {
                Letter = letter,
                NationOne = new Nation() { Name = "Test1", Points = 9 },
                NationTwo = new Nation() { Name = "Test2", Points = 6, GroupStageGoalsDifference = -1},
                NationThree = new Nation() { Name = "Test3", Points = 3 },
                NationFour = new Nation() { Name = "Test4", Points = 6, GroupStageGoalsDifference = 1}
            };
        }

        private List<Nation> SetUpNations(int count)
        {
            List<Nation> result = new List<Nation>();
            for (int i = 0; i < count; i++)
            {
                result.Add(new Nation
                {
                    Name = $"Test-{i}",
                    Ranking = (count - i) + 1,
                    Confederation = "Testavania"
                });
            }

            return result.OrderBy(i => i.Ranking).ToList();
        }
    }
}
