using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Shouldly;
using WorldCup2018TDD.Data.Entities;
using WorldCup2018TDD.Data.Repositories;
using WorldCup2018TDD.Services;

namespace WorldCup2018TDDTests.ServiceTests
{
    [TestClass]
    public class NationServiceTests
    {
        private NationService _testee;
        private Mock<INationRepository> _nationRepositoryMock;

        [TestInitialize]
        public void Init()
        {
            _nationRepositoryMock = new Mock<INationRepository>();
            _testee = new NationService(_nationRepositoryMock.Object);
        }

        [TestMethod]
        public void GetAllNations_Should_ReturnAllNations()
        {
            //Arrange
            _nationRepositoryMock.Setup(o => o.GetAllNations()).Returns(SetUpNations(32));

            //Action 
            var result = _testee.GetAllNations();

            //Assert 
            result.Count.ShouldBe(32);
            var curNation = result[0];
            //Step Through the items and ensure that all the nations are ordered correctly
            for (int i = 1; i < 32; i++)
            {
                result[i].Ranking.ShouldBeGreaterThan(curNation.Ranking);
                curNation = result[i];
            }
        }

        [TestMethod]
        public void GetNationByName_Should_ReturnNationWithCorrectName()
        {
            //Arrange
            _nationRepositoryMock.Setup(o => o.GetNationByName("Test")).Returns(new Nation() { Name = "Test" });

            //Action
            var result = _testee.GetNationByName("Test");

            //Assert
            result.Name.ShouldBe("Test");
        }

        [TestMethod]
        public void GetNationsByGroup_Should_ReturnsListOfNations()
        {
            //Arrange 
            _nationRepositoryMock.Setup(o => o.GetNationsByGroup("A")).Returns(SetUpGetNationsByGroup("A"));

            //Action
            List<Nation> result = _testee.GetNationsByGroup("A");

            //Assert
            result.ShouldBeOfType<List<Nation>>();
            result.Count.ShouldBe(4);
            for (int i = 0; i < 4; i++)
            {
                result[i].GroupLetter.ShouldBe("A");
            }
        }

        private List<Nation> SetUpGetNationsByGroup(string letter)
        {
            List<Nation> result = new List<Nation>();
            for (int i = 0; i < 4; i++)
            {
                result.Add(new Nation() {
                    GroupLetter = letter
                });
            }
            return result;
        }

        private List<Nation> SetUpNations(int count)
        {
            List<Nation> result = new List<Nation>();
            for (int i = 0; i < count; i++)
            {
                result.Add(new Nation
                {
                    Name = $"Test-{i}",
                    Ranking = (count - i) + 1,
                    Confederation = "Testavania"
                });
            }
            
            return result.OrderBy(i => i.Ranking).ToList();
        }
    }
}
